"use client";
import { useEffect, useState } from "react";

type Pedido = {
  numero: string;
  itens: string[];
  valor: number;
  hora: string;
  status: "pendente" | "aceito" | "recusado";
  nomeCliente: string;
  endereco: string;
  formaPagamento: string;
};

export default function DashboardVendedorPage() {
  const [pedidos, setPedidos] = useState<Pedido[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem("pedidos");
    if (saved) setPedidos(JSON.parse(saved));
  }, []);

  useEffect(() => {
    localStorage.setItem("pedidos", JSON.stringify(pedidos));
  }, [pedidos]);

  useEffect(() => {
    const eventSource = new EventSource("/api/notificacoes");

    eventSource.onmessage = (e) => {
      try {
        const pedido = JSON.parse(e.data);

        setPedidos((prev) => {
          const jaExiste = prev.some((p) => p.numero === pedido.numero);
          if (jaExiste) return prev;

          return [
            {
              numero: pedido.numero,
              itens: pedido.itens || [],
              valor: pedido.valor || 0,
              hora: pedido.hora || new Date().toLocaleTimeString("pt-BR"),
              status: "pendente",
              nomeCliente: pedido.nomeCliente || "Cliente",
              endereco: pedido.endereco || "Endereço não informado",
              formaPagamento: pedido.formaPagamento || "Pix",
            },
            ...prev,
          ];
        });
      } catch (err) {
        console.error("Erro ao processar pedido:", err);
      }
    };

    return () => eventSource.close();
  }, []);

  const atualizarStatus = (numero: string, status: "aceito" | "recusado") => {
    setPedidos((prev) =>
      prev.map((pedido) =>
        pedido.numero === numero ? { ...pedido, status } : pedido
      )
    );
  };

  return (
    <div className="p-8 bg-gray-950 min-h-screen text-white">
      <h1 className="text-3xl font-bold mb-6 text-center">Painel do Vendedor</h1>

      {pedidos.length === 0 ? (
        <p className="text-gray-400 text-center">
          Nenhum pedido recebido ainda...
        </p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {pedidos.map((pedido) => (
            <div
              key={pedido.numero}
              className={`rounded-2xl shadow-lg p-6 border transition-all ${
                pedido.status === "pendente"
                  ? "border-blue-500 bg-gray-900"
                  : pedido.status === "aceito"
                  ? "border-green-500 bg-gray-800"
                  : "border-red-500 bg-gray-800"
              }`}
            >
              <h2 className="text-xl font-semibold mb-2">
                Pedido #{pedido.numero}
              </h2>
              <p className="text-gray-300 text-sm mb-4">
                {pedido.hora} —{" "}
                <span
                  className={`font-semibold ${
                    pedido.status === "pendente"
                      ? "text-blue-400"
                      : pedido.status === "aceito"
                      ? "text-green-400"
                      : "text-red-400"
                  }`}
                >
                  {pedido.status.toUpperCase()}
                </span>
              </p>

              <div className="mb-2">
                <p className="font-medium">Itens:</p>
                <ul className="list-disc list-inside text-gray-300 text-sm">
                  {pedido.itens.map((item, index) => (
                    <li key={index}>{item}</li>
                  ))}
                </ul>
              </div>

              <p className="mt-3 text-gray-300">
                <span className="font-medium">Cliente:</span>{" "}
                {pedido.nomeCliente}
              </p>
              <p className="text-gray-300">
                <span className="font-medium">Endereço:</span>{" "}
                {pedido.endereco}
              </p>
              <p className="text-gray-300">
                <span className="font-medium">Pagamento:</span>{" "}
                {pedido.formaPagamento}
              </p>

              <p className="mt-3 text-lg font-semibold text-green-400">
                Valor: R$ {pedido.valor.toFixed(2)}
              </p>

              {pedido.status === "pendente" && (
                <div className="flex gap-3 mt-5">
                  <button
                    onClick={() => atualizarStatus(pedido.numero, "aceito")}
                    className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg transition-all"
                  >
                    Aceitar
                  </button>
                  <button
                    onClick={() => atualizarStatus(pedido.numero, "recusado")}
                    className="flex-1 bg-red-600 hover:bg-red-700 text-white py-2 rounded-lg transition-all"
                  >
                    Recusar
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
