import { NextRequest } from "next/server";

let sendNotificacaoGlobal: ((msg: string) => void) | null = null;

export async function GET(req: NextRequest) {
  const stream = new ReadableStream({
    start(controller) {
      sendNotificacaoGlobal = (msg: string) => {
        controller.enqueue(`data: ${msg}\n\n`);
      };
    },
    cancel() {
      sendNotificacaoGlobal = null;
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  });
}

export async function POST(req: NextRequest) {
  try {
    const { pedido } = await req.json();

    if (sendNotificacaoGlobal) {
      // ✅ envia o objeto completo do pedido
      sendNotificacaoGlobal(JSON.stringify(pedido));
      return new Response("Notificação enviada", { status: 200 });
    }

    return new Response("Nenhum vendedor conectado", { status: 400 });
  } catch (error) {
    console.error("Erro ao enviar notificação:", error);
    return new Response("Erro interno", { status: 500 });
  }
}
