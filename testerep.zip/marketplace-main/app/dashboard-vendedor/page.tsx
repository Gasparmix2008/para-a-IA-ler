"use client";
import { useEffect, useState } from "react";

type PedidoStatus = "pendente" | "aceito" | "recusado";

type Pedido = {
  numero: string;
  itens: string[];
  valor: number;
  hora: string;
  status: PedidoStatus;
  nomeCliente?: string;
  endereco?: string;
  formaPagamento?: string;
};

function parsePriceFromString(item: string): number | null {
  const match = item.match(/R\$?\s*([0-9.,]+)/);
  if (!match) return null;
  const normalized = match[1].replace(/\./g, "").replace(",", ".");
  const value = parseFloat(normalized);
  return Number.isFinite(value) ? value : null;
}

export default function DashboardVendedorPage() {
  const [pedidos, setPedidos] = useState<Pedido[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem("pedidos");
    if (saved) setPedidos(JSON.parse(saved));
  }, []);

  // de vez em quando essa bosta buga, favor trocar urgente ;( ksks
  useEffect(() => {
    localStorage.setItem("pedidos", JSON.stringify(pedidos));
  }, [pedidos]);

  useEffect(() => {
    const eventSource = new EventSource("/api/notificacoes");

    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        const pedidoRaw = data.numero ? data : data.pedido || data;

        let valor = typeof pedidoRaw.valor === "number"
          ? pedidoRaw.valor
          : typeof pedidoRaw.valor === "string"
          ? parseFloat(pedidoRaw.valor.replace(/\./g, "").replace(",", "."))
          : 0;

        if (!valor) {
          let subtotal = 0;
          const itens: string[] = pedidoRaw.itens || [];
          itens.forEach((item) => {
            const price = parsePriceFromString(item);
            subtotal += price || 0;
          });
          const deliveryFee = subtotal >= 50 ? 0 : 5;
          valor = subtotal + deliveryFee;
        }

        const novoPedido: Pedido = {
          numero: pedidoRaw.numero || Math.floor(Math.random() * 100000).toString(),
          itens: pedidoRaw.itens || (pedidoRaw.descricao ? [pedidoRaw.descricao] : []),
          valor,
          hora: pedidoRaw.hora || new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
          status: "pendente",
          nomeCliente: pedidoRaw.nomeCliente || "Cliente",
          endereco: pedidoRaw.endereco || "Endereço não informado",
          formaPagamento: pedidoRaw.formaPagamento || "Pix",
        };

        setPedidos((prev) => (prev.some((p) => p.numero === novoPedido.numero) ? prev : [novoPedido, ...prev]));
      } catch (err) {
        console.error("Erro ao processar pedido SSE:", err);
      }
    };

    eventSource.onerror = (err) => console.error("SSE error:", err);

    return () => eventSource.close();
  }, []);

  const atualizarStatus = (numero: string, status: "aceito" | "recusado") => {
    setPedidos((prev) =>
      prev.map((pedido) => (pedido.numero === numero ? { ...pedido, status } : pedido))
    );
  };

  const statusBorderColor = (status: PedidoStatus) => {
    if (status === "pendente") return "#8e9436ff";
    if (status === "aceito") return "green";
    return "red";
  };

  const statusTextColor = (status: PedidoStatus) => {
    if (status === "pendente") return "#8e9436ff";
    if (status === "aceito") return "green";
    return "red";
  };

  return (
    <div className="p-8 bg-[#0a0a0a] min-h-screen text-white">
      <h1 className="text-3xl font-bold mb-6 text-center">TESTES PIKA DE PEDIDOOOSSSS</h1>

      {pedidos.length === 0 ? (
        <p className="text-gray-400 text-center">Nenhum pedido recebido ainda...</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {pedidos.map((pedido) => (
            <div
              key={pedido.numero}
              className="rounded-2xl shadow-lg p-6 border transition-all bg-[#121212]"
              style={{ borderColor: statusBorderColor(pedido.status) }}
            >
              <h2 className="text-xl font-semibold mb-2" style={{ color: "#d97757" }}>
                Pedido #{pedido.numero}
              </h2>
              <p className="text-gray-300 text-sm mb-4">
                {pedido.hora} —{" "}
                <span className="font-semibold" style={{ color: statusTextColor(pedido.status) }}>
                  {pedido.status.toUpperCase()}
                </span>
              </p>

              <div className="mb-2">
                <p className="font-medium">Itens:</p>
                <ul className="list-disc list-inside text-gray-300 text-sm">
                  {pedido.itens.map((item, index) => (
                    <li key={index}>{item}</li>
                  ))}
                </ul>
              </div>

              <p className="mt-3 text-gray-300">
                <span className="font-medium">Cliente:</span> {pedido.nomeCliente}
              </p>
              <p className="text-gray-300">
                <span className="font-medium">Endereço:</span> {pedido.endereco}
              </p>
              <p className="text-gray-300">
                <span className="font-medium">Pagamento:</span> {pedido.formaPagamento}
              </p>

              <p className="mt-3 text-lg font-semibold text-green-400">
                Valor: R$ {pedido.valor.toFixed(2)}
              </p>

              {/* Botões para pedidos pendentes */}
              {pedido.status === "pendente" && (
                <div className="flex gap-3 mt-5 bg-[#121212] p-4 rounded-lg">
                  <button
                    onClick={() => atualizarStatus(pedido.numero, "aceito")}
                    className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg transition-all"
                  >
                    Aceitar
                  </button>
                  <button
                    onClick={() => atualizarStatus(pedido.numero, "recusado")}
                    className="flex-1 bg-red-600 hover:bg-red-700 text-white py-2 rounded-lg transition-all"
                  >
                    Recusar
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
