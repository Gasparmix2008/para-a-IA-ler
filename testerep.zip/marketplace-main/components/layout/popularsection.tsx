import {
  Flame,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";

type Product = {
  id: number;
  name: string;
  price: number;
  description: string;
  reviews: number;
  prepTime: string;
  category: string;
  image: string;
  isPopular: boolean;
};

type PopularSectionProps = {
  products: Product[];
  scrollCarousel: (direction: "left" | "right") => void;
  carouselRef: React.RefObject<HTMLDivElement | null>;
  addToCart: (product: Product) => void;
};


export default function PopularSection({
  products,
  scrollCarousel,
  carouselRef,
  addToCart,
}: PopularSectionProps) {
  return (
    <section>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Flame className="w-5 h-5 text-[#e50914]" />
          <h2 className="text-xl font-bold">Populares</h2>
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => scrollCarousel("left")}
            className="p-2 hover:bg-card-hover rounded-full transition-colors"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            type="button"
            onClick={() => scrollCarousel("right")}
            className="p-2 hover:bg-card-hover rounded-full transition-colors"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div
        ref={carouselRef}
        className="flex gap-4 overflow-x-hidden scroll-smooth scrollbar-hide pb-2"
      >
        {products
          .filter((p) => p.isPopular)
          .map((product) => (
            <div
              key={product.id}
              className="w-90 h-75 bg-card rounded-2xl overflow-hidden shadow-sm flex-shrink-0"
            >
              <div className="relative">
                <img
                  src={product.image}
                  alt={product.name}
                  className="h-36 w-full object-cover"
                />
                <span className="absolute top-2 left-2 bg-primary text-white text-xs font-semibold px-2 py-1 rounded-full flex items-center gap-1">
                  🔥 Popular
                </span>
              </div>
              <div className="">
                <div className="p-3 space-y-1 flex-1">
                <h3 className="text-lg font-bold text-foreground mb-1 line-clamp-1">{product.name}</h3>
                <p className="text-sm text-muted-foreground mb-2 line-clamp-2">{product.description}</p>
                <div className="flex justify-between items-center pt-2">
                  <span className="font-bold text-lg">
                    R$ {product.price.toFixed(2)}
                  </span>
                  {/* <button
                    type="button"
                    onClick={() => addToCart(product)}
                    className="text-sm bg-white text-black font-semibold px-3 py-1 rounded-md hover:bg-zinc-200 transition"
                  >
                    Adicionar
                  </button> */}
                </div>
              </div>
              </div>
            </div>
          ))}
      </div>
    </section>
  );
}