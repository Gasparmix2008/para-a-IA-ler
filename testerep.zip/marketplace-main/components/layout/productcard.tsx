import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import {
  Dialog,
  DialogClose,
  DialogOverlay,
  DialogContent,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Flame, X } from "lucide-react";
type Product = {
  id: number;
  name: string;
  price: number;
  description: string;
  reviews: number;
  prepTime: string;
  category: string;
  image: string;
  isPopular: boolean;
};

type ProductCardProps = {
  product: Product;
  favorites: number[];
  addToCart: (product: Product) => void;
};

export default function ProductCard({
  product,
  favorites,
  addToCart,
}: ProductCardProps) {
  return (
    <div className="rounded-xl flex items-center justify-between shadow-sm hover:shadow-md transition ">
      <Dialog>
        <form>
          <DialogTrigger asChild>
            <button className="flex relative">
              {product.isPopular ? (
                  <div className="absolute m-1 mx-3 flex items-center gap-2 text-sm px-1 py-1 bg-[#e50914]/10 rounded-xl">
                    <Flame className=" w-5 h-5 text-[#e50914]" />
                    <span className="text-[#e50914]">Popular</span>
                  </div>
              ) : ""}
              <Card className="flex cursor-pointer hover:bg-accent transition border-0">
                <CardContent className="flex p-3 w-full">
                  <div className="flex-1 text-start pr-4">
                    <h3 className="text-lg font-bold text-foreground mb-1 line-clamp-1">
                      {product.name}
                    </h3>
                    <p className="text-sm text-muted-foreground mb-2 line-clamp-2">
                      {product.description}
                    </p>
                    <span className="text-base font-bold text-lg">
                      R$ {product.price}
                    </span>
                  </div>

                  {/* IMAGE */}
                  <div className="w-28 h-28 flex-shrink-0">
                    <div className="aspect-square w-full overflow-hidden rounded-lg">
                      <img
                        src={product.image}
                        alt={product.name}
                        className="w-full h-full object-cover rounded-lg transform hover:scale-105 transition duration-300"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px] max-h-[90vh] border-0 p-0 overflow-hidden">
            {/* Header com imagem de fundo */}
            <div className="relative w-full h-72 overflow-hidden">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent"></div>

              {/* Botão de fechar customizado */}
              <DialogClose className="absolute top-4 right-4 rounded-full bg-background/80 backdrop-blur-sm p-2 hover:bg-background transition-colors">
                <X className="h-4 w-4" />
              </DialogClose>
            </div>

            {/* Conteúdo do produto */}
            <div className="px-6 pb-6 -mt-16 relative z-10">
              <div className="bg-background rounded-2xl p-6 shadow-xl">
                <DialogTitle className="text-2xl font-bold text-foreground mb-3">
                  {product.name}
                </DialogTitle>

                <p className="text-muted-foreground mb-6 leading-relaxed">
                  {product.description}
                </p>

                {/* Preço destacado */}
                <div className="flex items-baseline gap-2 mb-6">
                  <span className="text-3xl font-bold text-foreground">
                    R$ {product.price}
                  </span>
                  <span className="text-sm text-muted-foreground">
                    /unidade
                  </span>
                </div>

                {/* Informações adicionais */}
                <div className="space-y-3 mb-6 p-4 bg-muted/30 rounded-lg">
                  <div className="flex items-center gap-2 text-sm">
                    <div className="w-2 h-2 rounded-full bg-green-500"></div>
                    <span className="text-muted-foreground">Disponível em estoque</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                    <span className="text-muted-foreground">Entrega rápida • {product.prepTime}</span>
                  </div>
                </div>

                {/* Botão de ação */}
                <DialogClose asChild>
                  <Button
                    onClick={() => addToCart(product)}
                    className="w-full h-12 text-base font-semibold shadow-lg hover:shadow-xl transition-all"
                    variant="default"
                  >
                    Adicionar ao carrinho
                  </Button>
                </DialogClose>
              </div>
            </div>
          </DialogContent>
        </form>
      </Dialog>
    </div>

  );
}