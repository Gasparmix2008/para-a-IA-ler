"use client";
import { X, Plus, Minus, ShoppingBag, Truck, LoaderCircle } from "lucide-react";
import { useState } from "react";

type CartItem = {
  id: number;
  name: string;
  price: number;
  quantity: number;
  image: string;
};

type CartDialogProps = {
  cart: CartItem[];
  open: boolean;
  onOpenChange: (open: boolean) => void;
  updateQuantity: (id: number, delta: number) => void;
  removeFromCart: (id: number) => void;
  cartTotal: number;
};

export default function CartDialog({
  cart,
  open,
  onOpenChange,
  updateQuantity,
  removeFromCart,
  cartTotal,
}: CartDialogProps) {
  if (!open) return null;
  const [loading, setLoading] = useState(false);

  const deliveryFee = cartTotal >= 50 ? 0 : 5.0;

  const calculatedTotal = cart.reduce(
    (acc, item) => acc + item.price * item.quantity,
    0
  );

  const finalTotal = Number((calculatedTotal + deliveryFee).toFixed(2));

  async function sendOrder() {
    if (cart.length === 0) return;
    setLoading(true);

    try {
      const numero = String(Math.floor(1000 + Math.random() * 9000));
      const hora = new Date().toLocaleTimeString("pt-BR", {
        hour: "2-digit",
        minute: "2-digit",
      });

      const itens = cart.map(
        (item) =>
          `${item.quantity}x ${item.name} (R$ ${(item.price * item.quantity).toFixed(2)})`
      );

      const pedido = {
        numero,
        nomeCliente: "Luiz Rabelo",
        formaPagamento: "Pix",
        valor: finalTotal,
        endereco: "Pedralinda - Rua 24 - N°400",
        itens,
        hora,
      };

      const pedidosSalvos =
        JSON.parse(localStorage.getItem("pedidos") || "[]") || [];
      pedidosSalvos.push(pedido);
      localStorage.setItem("pedidos", JSON.stringify(pedidosSalvos));

      await fetch("/api/notificacoes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pedido }),
      });

      setTimeout(() => {
        setLoading(false);
        onOpenChange(false);
        window.dispatchEvent(new CustomEvent("novo-pedido", { detail: pedido }));
        window.dispatchEvent(new CustomEvent("clear-cart"));
      }, 1500);
    } catch (error) {
      console.error("Erro ao enviar pedido:", error);
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 z-100 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="fixed right-0 top-0 h-full w-full max-w-md bg-background shadow-2xl animate-in slide-in-from-right duration-300">
        <div className="flex h-full flex-col">
          {/* Header */}
          <div className="relative bg-muted/30 p-6 text-primary-foreground">
            <button
              onClick={() => onOpenChange(false)}
              className="absolute right-4 top-4 rounded-full p-2 hover:bg-primary-foreground/20 transition-all duration-200"
              aria-label="Fechar carrinho"
            >
              <X className="h-5 w-5" />
            </button>
            <div className="flex items-center gap-3">
              <div className="rounded-full p-3 backdrop-blur-sm">
                <ShoppingBag className="h-6 w-6" />
              </div>
              <div>
                <h2 className="text-2xl font-bold">Meu Carrinho</h2>
                <p className="text-sm text-primary-foreground/90">
                  {cart.length} {cart.length === 1 ? "item" : "itens"}
                </p>
              </div>
            </div>
          </div>

          {/* Itens */}
          <div className="flex-1 overflow-y-auto p-4 bg-muted/30">
            {cart.length === 0 ? (
              <div className="flex h-full flex-col items-center justify-center text-muted-foreground">
                <ShoppingBag className="h-20 w-20 mb-4 opacity-20" />
                <p className="text-lg font-medium">Seu carrinho está vazio</p>
                <p className="text-sm mt-2">
                  Adicione itens deliciosos para começar!
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {cart.map((item) => (
                  <div
                    key={item.id}
                    className="flex gap-4 rounded-xl bg-card p-4 shadow-sm hover:shadow-md transition-all duration-200 border border-border"
                  >
                    <img
                      src={item.image}
                      alt={item.name}
                      className="h-24 w-24 rounded-lg object-cover ring-2 ring-border"
                    />
                    <div className="flex flex-1 flex-col justify-between">
                      <div>
                        <h3 className="font-semibold text-card-foreground line-clamp-1">
                          {item.name}
                        </h3>
                        <p className="text-lg text-primary font-bold mt-1">
                          R$ {(item.price * item.quantity).toFixed(2)}
                        </p>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 bg-muted/40 rounded-full p-1">
                          <button
                            onClick={() => updateQuantity(item.id, -1)}
                            className="rounded-full bg-background/50 p-1.5 hover:bg-primary hover:text-primary-foreground transition-all duration-200 shadow-sm"
                          >
                            <Minus className="h-4 w-4" />
                          </button>
                          <span className="w-8 text-center font-bold">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => updateQuantity(item.id, 1)}
                            className="rounded-full bg-background/50 p-1.5 hover:bg-primary hover:text-primary-foreground transition-all duration-200 shadow-sm"
                          >
                            <Plus className="h-4 w-4" />
                          </button>
                        </div>
                        <button
                          onClick={() => removeFromCart(item.id)}
                          className="text-destructive hover:text-destructive/80 hover:bg-destructive/10 p-2 rounded-lg transition-all duration-200"
                        >
                          <X className="h-5 w-5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Resumo */}
          {cart.length > 0 && (
            <div className="border-t border-border bg-card p-4 space-y-4">
              <div className="space-y-2 text-sm">
                <div className="flex justify-between text-muted-foreground">
                  <span>Subtotal</span>
                  <span className="font-semibold text-foreground">
                    R$ {calculatedTotal.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <Truck className="h-4 w-4" />
                    <span>Entrega</span>
                  </div>
                  <span
                    className={`font-semibold ${
                      deliveryFee === 0
                        ? "text-green-500 bg-green-500/10 px-3 py-1 rounded-sm"
                        : "text-foreground"
                    }`}
                  >
                    {deliveryFee === 0
                      ? "GRÁTIS"
                      : `R$ ${deliveryFee.toFixed(2)}`}
                  </span>
                </div>

                {/* ✅ AQUI entra o campo de "faltam R$..." */}
                {calculatedTotal < 50 && (
                  <p className="text-xs text-primary bg-primary/10 p-2 rounded-lg">
                    Faltam R$ {(50 - calculatedTotal).toFixed(2)} para entrega grátis!
                  </p>
                )}

                <div className="h-px bg-border my-2"></div>
                <div className="flex justify-between text-lg font-bold">
                  <span>Total</span>
                  <span className="text-primary">R$ {finalTotal.toFixed(2)}</span>
                </div>
              </div>

              <button
                className={`w-full rounded-xl ${
                  loading ? "bg-green-400" : "bg-primary"
                } py-4 font-bold text-primary-foreground hover:bg-primary/90 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-[1.02] active:scale-[0.98] flex items-center justify-center`}
                onClick={sendOrder}
                disabled={loading}
              >
                {loading ? (
                  <LoaderCircle className="animate-spin" />
                ) : (
                  "Finalizar Pedido"
                )}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
