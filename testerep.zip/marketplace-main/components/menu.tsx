// components/Menu.tsx
"use client";
import User from "./UserDrop";
import { ShoppingCart } from "lucide-react";
import { useState } from "react";
import CartDialog from "./layout/cartdialog";
import { useCart } from "@/contexts/CartContext";
import { usePathname } from "next/navigation";

export default function Menu() {
  const [showCart, setShowCart] = useState(false);
  const { cart, updateQuantity, removeFromCart, cartTotal, cartCount } = useCart();
  const pathname = usePathname();

  if (pathname === "/dashboard-vendedor") return null;

  return (
    <>
      <header className="flex-row-reverse flex bottom-0 min-md:px-45 z-40 items-center justify-between py-5 px-10 fixed w-full border-b border-border shadow-xl bg-neutral-950/90 backdrop-blur-sm">       
        <button
          type="button"
          onClick={() => setShowCart(true)}
          className="relative p-2 hover:bg-card-hover rounded-full transition-colors"
        >
          <ShoppingCart className="w-6 h-6" />
          {cartCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-primary text-white text-xs w-5 h-5 rounded-full flex items-center justify-center font-semibold">
              {cartCount}
            </span>
          )}
        </button>
        
        <nav>
          <ul className="flex items-center gap-4">
            <User />
          </ul>
        </nav>
      </header>

      <CartDialog
        cart={cart}
        open={showCart}
        onOpenChange={setShowCart}
        updateQuantity={updateQuantity}
        removeFromCart={removeFromCart}
        cartTotal={cartTotal}
      />
    </>
  );
}