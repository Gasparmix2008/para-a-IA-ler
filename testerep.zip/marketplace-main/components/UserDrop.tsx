"use client";
import Link from "next/link";
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuShortcut,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from "@/components/ui/avatar"


export default function Menu() {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost">
          <Avatar>
            <AvatarFallback>DV</AvatarFallback>
          </Avatar>
          Minha conta
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-56 m-3" align="end">
        <DropdownMenuLabel className="py-2">
          Minha conta
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuGroup className="flex flex-col gap-2">
          <a href="#" onClick={(e) => e.preventDefault()}>
            <DropdownMenuItem>
              Meus pedidos
              <DropdownMenuShortcut>CTRL + P</DropdownMenuShortcut>
            </DropdownMenuItem>
          </a>


          <DropdownMenuItem>
            Meus endereços
            <DropdownMenuShortcut>CTRL + E</DropdownMenuShortcut>
          </DropdownMenuItem>
          <Link href="/dashboard-vendedor">
            <DropdownMenuItem>Perfil vendedor</DropdownMenuItem>
          </Link>
        </DropdownMenuGroup>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
