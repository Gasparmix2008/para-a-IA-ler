// components/home.tsx
"use client";
import ProductCard from "@/components/layout/productcard";
import PopularSection from "@/components/layout/popularsection";
import products from "@/app/_api/products";
import { useState, useRef } from "react";
import {
  Search,
  MapPin,
  ChevronDown,
  Clock,
} from "lucide-react";
import { useCart } from "@/contexts/CartContext";

type Category = {
  id: string;
  label: string;
  icon: string;
};

const categories: Category[] = [
  { id: "all", label: "Todos", icon: "🍽️" },
  { id: "espetos", label: "Espetos", icon: "🍢" },
  { id: "petiscos", label: "Petiscos", icon: "🍤" },
  { id: "acompanhamentos", label: "Acompanhamentos", icon: "🍛" },
  { id: "bebidas", label: "Bebidas", icon: "🍺" },
  { id: "destilados", label: "Destilados", icon: "🥃" },
  { id: "sucos", label: "Sucos", icon: "🍹" },
  { id: "diversos", label: "Diversos", icon: "🧃" },
];

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [favorites, setFavorites] = useState<number[]>([]);
  const carouselRef = useRef<HTMLDivElement>(null);

  const { addToCart, cartCount } = useCart();

  const getBusinessStatus = () => {
    const now = new Date();
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();
    const openHour = 10;
    const closeHour = 23;
    const isOpen = currentHour >= openHour && currentHour < closeHour;
    const currentTime = `${currentHour.toString().padStart(2, "0")}:${currentMinute
      .toString()
      .padStart(2, "0")}`;
    return { isOpen, currentTime, openHour, closeHour };
  };

  const businessStatus = getBusinessStatus();

  const scrollCarousel = (direction: "left" | "right") => {
    if (carouselRef.current) {
      const scrollAmount = 376;
      carouselRef.current.scrollBy({
        left: direction === "left" ? -scrollAmount : scrollAmount,
        behavior: "smooth",
      });
    }
  };

  const filteredProducts = products.filter((product) => {
    const search = searchQuery.toLowerCase();
    return (
      (product.name.toLowerCase().includes(search)) &&
      (selectedCategory === "all" || product.category === selectedCategory)
    );
  });

  return (
    <div className="min-h-screen text-foreground min-md:px-40">
      {/* HEADER */}
      <div className="absolute left-0 w-full -z-100 -mt-10 h-96 pointer-events-none">
        <img
          src="Background.png"
      
          alt="Background"
          className="w-full h-full object-cover relative"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-background/50 to-background"></div>
      </div> {/* FINALIZADO 🟢 */}
      
      <div className="relative z-50">
        <div className="p-4 space-y-4">
          <div className="flex gap-3">
            {/* Card de Localização */}
            <div className="flex w-3/5 flex items-center bg-card/70 backdrop-blur-[4px] text-foreground rounded-xl border border-foreground/10 overflow-hidden">
              <button
                type="button"
                className="flex items-center gap-2 hover:bg-card-hover px-4 py-3 rounded-lg transition-colors w-full"
              >
                <MapPin className="w-5 h-5 text-foreground flex-shrink-0" />
                <div className="text-left min-w-0 flex-1">
                  <div className="font-semibold truncate">
                    Rua da Polonia, 20 - Areia Branca
                  </div>
                </div>
              </button>
            </div>

            {/* Card de Status */}
            <div
              className={`flex w-2/5 flex items-center justify-between px-4 py-3 rounded-xl bg-card/70 backdrop-blur-[4px] border ${businessStatus.isOpen
                  ? "bg-green-500/10 border-green-500/20"
                  : "bg-red-500/10 border-red-500/20"
                }`}
            >
              <div className="flex items-center gap-2 min-w-0">
                <Clock
                  className={`w-5 h-5 flex-shrink-0 ${businessStatus.isOpen ? "text-success" : "text-destructive"
                    }`}
                />
                <div className="min-w-0">
                  <div className="font-semibold text-sm whitespace-nowrap">
                    {businessStatus.isOpen ? "Aberto" : "Fechado"}
                  </div>
                  <div className="text-[12px] text-muted-foreground block">
                    {businessStatus.openHour}:00 - {businessStatus.closeHour}:00
                  </div>
                </div>
              </div>
            </div>
          </div>


          {/* Campo de busca */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 z-10 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <input
              type="text"
              placeholder="Pesquisar..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-12 py-3 bg-card/70 backdrop-blur-[4px] text-foreground outline-none rounded-lg border border-foreground/10"
            />
          </div>

          {/* Filtros */}
          <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4 overflow-hidden mt-20">
            {categories.map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setSelectedCategory(cat.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-full whitespace-nowrap transition-all ${selectedCategory === cat.id
                  ? "bg-primary text-white"
                  : "bg-card hover:bg-card-hover"
                  }`}
              >
                <span>{cat.icon}</span>
                <span className="font-medium">{cat.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* MAIN */}
      <main className="p-4 space-y-6">
        {/* POPULARES */}
        {selectedCategory === "all" && searchQuery === "" && (
          <PopularSection
            products={products}
            scrollCarousel={scrollCarousel}
            carouselRef={carouselRef}
            addToCart={addToCart}
          />
        )}

        {/* TODOS OS PRODUTOS */}
        <section>
          {filteredProducts.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Search className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>Nenhum produto encontrado</p>
            </div>
          ) : (
            Object.entries(
              filteredProducts.reduce((acc, product) => {
                if (!acc[product.category]) acc[product.category] = [];
                acc[product.category].push(product);
                return acc;
              }, {} as Record<string, typeof filteredProducts>)
            ).map(([category, products]) => (
              <div key={category}>  
                <h3 className="uppercase font-bold text-lg py-5 pb-10 max-sm:text-center">
                  {category}
                </h3>
                <div className="grid md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
                  {products.map((product) => (
                    <ProductCard
                      key={product.id}
                      product={product}
                      favorites={favorites}
                      addToCart={addToCart}
                    />
                  ))}
                </div>
              </div>
            ))
          )}
        </section>
      </main>
    </div>
  );
}