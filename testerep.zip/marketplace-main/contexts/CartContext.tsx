// contexts/CartContext.tsx
"use client";
import {
  createContext,
  useContext,
  useEffect,
  useState,
  ReactNode,
} from "react";

type CartItem = {
  id: number;
  name: string;
  price: number;
  quantity: number;
  image: string;
};

type Product = {
  id: number;
  name: string;
  price: number;
  description: string;
  reviews: number;
  prepTime: string;
  category: string;
  image: string;
  isPopular: boolean;
};

type CartContextType = {
  cart: CartItem[];
  addToCart: (product: Product) => void;
  updateQuantity: (id: number, delta: number) => void;
  removeFromCart: (id: number) => void;
  cartTotal: number;
  cartCount: number;
  finalizarPedido: () => Promise<void>;
};

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartItem[]>([]);

  // ✅ Carrega o carrinho do localStorage ao iniciar
  useEffect(() => {
    const savedCart = localStorage.getItem("cart");
    if (savedCart) {
      setCart(JSON.parse(savedCart));
    }
  }, []);

  // ✅ Salva o carrinho sempre que mudar
  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cart));
  }, [cart]);

  // ✅ Escuta o evento "clear-cart" vindo de outros componentes
  useEffect(() => {
    const clearCartHandler = () => setCart([]);
    window.addEventListener("clear-cart", clearCartHandler);
    return () => window.removeEventListener("clear-cart", clearCartHandler);
  }, []);

  const addToCart = (product: Product) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [
        ...prev,
        {
          id: product.id,
          name: product.name,
          price: product.price,
          quantity: 1,
          image: product.image,
        },
      ];
    });
  };

  const updateQuantity = (id: number, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) =>
          item.id === id
            ? { ...item, quantity: Math.max(0, item.quantity + delta) }
            : item
        )
        .filter((item) => item.quantity > 0)
    );
  };

  const removeFromCart = (id: number) =>
    setCart((prev) => prev.filter((item) => item.id !== id));

  const cartTotal = cart.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  // 🧾 Função para enviar o pedido ao vendedor e limpar carrinho
  const finalizarPedido = async () => {
    if (cart.length === 0) return;

    const itens = cart.map(
      (item) => `${item.quantity}x ${item.name}`
    );

    const total = cart
      .reduce((acc, item) => acc + item.price * item.quantity, 0)
      .toFixed(2);

    try {
      await fetch("/api/notificacoes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          itens,
          total,
          data: new Date().toISOString(),
        }),
      });

      // ✅ Limpa carrinho local e no storage
      setCart([]);
      localStorage.removeItem("cart");

      // ✅ Dispara evento global para sincronizar
      window.dispatchEvent(new Event("clear-cart"));
    } catch (error) {
      console.error("Erro ao enviar pedido:", error);
    }
  };

  return (
    <CartContext.Provider
      value={{
        cart,
        addToCart,
        updateQuantity,
        removeFromCart,
        cartTotal,
        cartCount,
        finalizarPedido,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return context;
}
